1. The Marvell Mac MSU v4.1.0.2038_2 supports from the Mac OS 10.15.
   If users want to use Mac OS 10.14 or below version, please use the Marvell Mac MSU v4.1.0.2037.
   
2. Known issue:
   a. Open the login page needs to wait about 30sec.
   b. After enter the account and pwd and press login button and needs to wait for about 30sec.
   c. After showing the main page, controller and HDD won��t show automatically and need to press ��Rescan�� button to show controller/HDD.